-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2020 at 09:51 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `logindb`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `username` varchar(30) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `department` varchar(30) NOT NULL,
  `description` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobileno` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`username`, `userid`, `date`, `department`, `description`, `email`, `mobileno`) VALUES
('Donald William', 'Donald', '2020-12-11', 'Software', 'Incorrect data edits so unreliable results', 'anjalianil2509@gmail.com', 8796097666);

-- --------------------------------------------------------

--
-- Table structure for table `employeedata`
--

CREATE TABLE `employeedata` (
  `Username` varchar(10) DEFAULT NULL,
  `Userid` varchar(20) DEFAULT NULL,
  `Field` varchar(10) DEFAULT NULL,
  `available` varchar(30) DEFAULT NULL,
  `mobileno` bigint(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeedata`
--

INSERT INTO `employeedata` (`Username`, `Userid`, `Field`, `available`, `mobileno`, `email`) VALUES
('admin', 'admin123', 'Hardware', 'true', 0, 'anjalianil2509@gmail.com'),
('worker1', 'worker1', 'Hardware', 'true', 0, 'anjalianil2509@gmail.com'),
('worker2', 'worker2', 'Software', 'true', 0, 'anjalianil2509@gmail.com'),
('worker3', 'worker3', 'Networking', 'true', 0, 'anjalianil2509@gmail.com'),
('worker4', 'worker4', 'Security', 'true', 0, 'anjalianil2509@gmail.com'),
('David', 'dv110', 'Networking', 'true', 5678904563, 'anjalianil2509@gmail.com'),
('Saily', 'sa123', 'Security', 'true', 7869079854, 'anjalianil2509@gmail.com'),
('Vickey', 'vv121', 'Software', 'true', 7685940945, 'anjalianil2509@gmail.com'),
('Ranbeer', 'rr342', 'Hardware', 'true', 9879087865, 'anjalianil2509@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `logid` varchar(20) DEFAULT NULL,
  `logpaswd` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `logpaswd`) VALUES
('customer1', '101'),
('customer1', '101'),
('customer3', '103'),
('admin', '1234'),
('anjali', '1259'),
('admin123', 'admin123'),
('admin001', '007'),
('customer4', '104'),
('employee1', '111'),
('employee2', '222'),
('employee3', '333'),
('employee4', '444'),
('John', 'john123'),
('Donald', 'donald09'),
('Mayank', 'my123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
